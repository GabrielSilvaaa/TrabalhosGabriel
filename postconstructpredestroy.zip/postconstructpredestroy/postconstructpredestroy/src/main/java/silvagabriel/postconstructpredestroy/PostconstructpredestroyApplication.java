package silvagabriel.postconstructpredestroy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import silvagabriel.postconstructpredestroy.model.Client;
import silvagabriel.postconstructpredestroy.dao.ClienteDAO;

@SpringBootApplication
public class PostconstructpredestroyApplication {

	public static void main(String[] args) {

	ApplicationContext applicationContext = SpringApplication.run(PostconstructpredestroyApplication.class, args);

		ClienteDAO clienteDAO = applicationContext.getBean(ClienteDAO.class);

		Object name;

		clienteDAO.setClient(new Client( name: "Gabriel Silva"));

		System.out.println("Material ClienteDAO: " + clienteDAO);
		System.out.println("Material Cliente: " + clienteDAO.getClient());
	}

}
