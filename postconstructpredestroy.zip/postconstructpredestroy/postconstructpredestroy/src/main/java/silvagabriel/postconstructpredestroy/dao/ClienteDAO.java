package silvagabriel.postconstructpredestroy.dao;

import silvagabriel.postconstructpredestroy.model.Client;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


@Component
@Getter @Setter
public class ClienteDAO {

    @Autowired
    private Client client;

    @PostConstruct
    public void postConstructor() {System.out.println("O Material foi Criado");}

    @PreDestroy
    public void preDestroy() {System.out.println("O Material foi Fizalizado");}


    public void setClient(Client client) {

    }

    public String getClient() {

    }
}