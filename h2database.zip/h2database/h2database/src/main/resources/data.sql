insert  into funcionario(id_funcionario, nome, salario, rg)
    values(null, 'Gabriel Silva', 1500.89, 12345678901);

insert  into funcionario(id_funcionario, nome, salario, rg)
    values(null, 'Claudia Silva', 2500.89, 78945612307);