package silva.gabriel.injecaodedependencia.model;

import silva.gabriel.injecaodedependencia.interfaces.IAutomovel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
@Qualifier("car")
public class Moto implements IAutomovel {

    @Override
    public void barulho() {
        System.out.println("Bololololo");

    }
}
