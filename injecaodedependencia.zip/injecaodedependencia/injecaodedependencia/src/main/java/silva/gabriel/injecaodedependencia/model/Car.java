package silva.gabriel.injecaodedependencia.model;

import silva.gabriel.injecaodedependencia.interfaces.IAutomovel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import silva.gabriel.injecaodedependencia.interfaces.IAutomovel;

@Component
public class Car {

    @Autowired
    @Qualifier("car")
    private IAutomovel iAutomovel;

    public void execute() { iAutomovel.barulho();}

    }

