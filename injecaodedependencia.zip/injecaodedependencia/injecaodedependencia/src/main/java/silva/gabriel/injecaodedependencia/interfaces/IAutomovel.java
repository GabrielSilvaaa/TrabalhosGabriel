package silva.gabriel.injecaodedependencia.interfaces;

public interface IAutomovel {

    public void barulho();

}
