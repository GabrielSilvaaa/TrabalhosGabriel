package silva.gabriel.injecaodedependencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import silva.gabriel.injecaodedependencia.model.Car;

@SpringBootApplication
public class InjecaodedependenciaApplication {

	public static void main(String[] args) {

		ApplicationContext applicationContext = SpringApplication.run(InjecaodedependenciaApplication.class, args);

		Car car = applicationContext.getBean(Car.class);
		car.execute();


	}
}
