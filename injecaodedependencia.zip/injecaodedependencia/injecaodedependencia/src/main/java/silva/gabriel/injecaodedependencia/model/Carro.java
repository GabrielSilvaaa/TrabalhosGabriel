package silva.gabriel.injecaodedependencia.model;

import silva.gabriel.injecaodedependencia.interfaces.IAutomovel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

    @Component
    @Qualifier("Car")
    public class Carro implements IAutomovel {

        @Override
        public void barulho() {
            System.out.println("Vrummmm");
    }

}
