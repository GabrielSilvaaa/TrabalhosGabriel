package IntellijIDEA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Gabriel da Silva Pereira
 * @return Project Maven
 */

@SpringBootApplication
public class GradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradleApplication.class, args);

		System.out.println("Hello World com Maven");
	}

}
