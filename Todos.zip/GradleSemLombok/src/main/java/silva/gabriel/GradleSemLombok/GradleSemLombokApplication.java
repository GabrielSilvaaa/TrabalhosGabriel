package silva.gabriel.GradleSemLombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradleSemLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradleSemLombokApplication.class, args);
	}

	package silva.gabriel.exemploGradleComLombok.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

	@RestController
	public class ClientController {

		@GetMapping("/Clientes")
		public Client getClient() {

			Client client = new Client();
			client.setName("Nerci");
			client.setLastName("Silva");
			client.setEmail("nerci.8130@gmail.com.br");

			return client;
		}

		@GetMapping("/Listclientes")
		public ArrayList<Client> getListClient() {

			Client client1 = new Client();
			client1.setName("Alvorim");
			client1.setLastName("Silva");
			client1.setEmail("alvorim.3642@gmail.com.br");

			Client client2 = new Client();
			client2.setName("Kiko");
			client2.setLastName("Silva");
			client2.setEmail("kiko.201030@gmail.com.br");

			ArrayList<Client> clients = new ArrayList<>();
			clients.add(client1);
			clients.add(client2);

			return clients;
		}
	}


}
