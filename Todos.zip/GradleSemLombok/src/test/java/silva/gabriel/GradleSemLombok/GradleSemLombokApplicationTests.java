package silva.gabriel.GradleSemLombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleSemLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
