package IntellijIDEA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
