package silva.gabriel.GradleComLombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradleComLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
