package silva.gabriel.exemploGradleComLombok.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;

@RestController
public class ClientController {

	@GetMapping("/Clientes")
	public Client getClient() {

		Client client = new Client();
		client.setName("Claudia");
		client.setLastName("Silva");
		client.setEmail("claudia.63598@gmail.com.br");

		return client;
	}

	@GetMapping("/Listclientes")
	public ArrayList<Client> getListClient() {

		Client client1 = new Client();
		client1.setName("Antônio");
		client1.setLastName("Silva");
		client1.setEmail("antonio.4520@gmail.com.br");

		Client client2 = new Client();
		client2.setName("Gabriel");
		client2.setLastName("Silva");
		client2.setEmail("gabriel.102030@gmail.com.br");

		ArrayList<Client> clients = new ArrayList<>();
		clients.add(client1);
		clients.add(client2);

		return clients;
	}
}
