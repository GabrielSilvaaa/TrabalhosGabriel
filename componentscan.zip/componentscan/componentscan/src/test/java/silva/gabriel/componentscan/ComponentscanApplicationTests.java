package silva.gabriel.componentscan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComponentscanApplicationTests {

	@Test
	void contextLoads() {
	}

}
