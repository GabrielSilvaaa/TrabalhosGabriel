package silva.gabriel.componentscan.externalclasses;

import org.springframework.stereotype.Component;

@Component
public class ClassJDBC {

    public ClassJDBC() {
        System.out.println("Aqui está a Conexão JDBC");
    }

}